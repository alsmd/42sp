#include "tower.h"
#include <stdio.h>

void	update_value_field(t_field *number, int size, t_field **tabuleiro)
{
	int	indice;
	int	value;

	indice = 0;
	while (indice < size)
	{
		if (number->prob[indice] != 0)
		{
			value = indice + 1;
			number->number = value;
			number->solvable = -1;
			update_tabuleiro(tabuleiro, number->row, number->col, size);
			break ;
		}
		indice++;
	}
}

void	update_prob_field(t_field *number, int number_found, int size, t_field **tab)
{
	if (number->number == 0)
	{
		if (number->prob[number_found - 1] != 0)
		{
			number->solvable -= 1;
			number->prob[number_found - 1] = 0;
		}
		if (number->solvable <= 1)
			update_value_field(number, size, tab);
	}
}

void	update_tabuleiro(t_field **tab, int row, int col, int size)
{
	int	indice;
	int	number_found;

	indice = 0;
	number_found = tab[row][col].number;
	while (indice < size)
	{
		update_prob_field(&tab[indice][col], number_found, size, tab);
		indice++;
	}
	indice = 0;
	while (indice < size)
	{
		update_prob_field(&tab[row][indice], number_found, size, tab);
		indice++;
	}
}
