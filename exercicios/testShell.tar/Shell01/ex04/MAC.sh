ifconfig | grep -e ether| tr -s ' ' | cut -d ' ' -f3
